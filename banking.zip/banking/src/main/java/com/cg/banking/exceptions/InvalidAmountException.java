package com.cg.banking.exceptions;
@SuppressWarnings("serial")
public class InvalidAmountException extends Exception {

}
